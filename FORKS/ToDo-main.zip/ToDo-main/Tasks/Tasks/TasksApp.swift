//
//  TasksApp.swift
//  Tasks
//
//  Created by Justin Bush on 2021-07-08.
//

import SwiftUI

@main
struct TasksApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
