//
//  ToDoApp.swift
//  ToDo
//
//  Created by Justin Bush on 2021-07-08.
//

import SwiftUI

@main
struct ToDoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
