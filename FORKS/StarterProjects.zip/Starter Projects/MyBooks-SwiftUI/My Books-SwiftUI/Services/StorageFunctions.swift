//
//  StorageFunctions.swift
//  CTHelpSPMMaster
//
//  Created by Stewart Lynch on 2019-06-28.
//  Copyright © 2019 CreaTECH Solutions. All rights reserved.
//

import Foundation

class StorageFunctions {
    
    static func retrieveBooks() -> [BookItem] {
         
        return []
    }
    
    
    static func storeBooks(books:[BookItem]) {
        
    }
}
